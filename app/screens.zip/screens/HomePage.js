import React from 'react';

function HomePage(props) {
    return (
        <View>
            
        </View>
    );
}

export default HomePage;